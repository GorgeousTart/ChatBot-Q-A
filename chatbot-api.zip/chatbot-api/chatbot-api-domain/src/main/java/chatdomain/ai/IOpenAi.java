package chatdomain.ai;

import java.io.IOException;

public interface IOpenAi {

    String doChatGPT(String question) throws IOException ;


}
