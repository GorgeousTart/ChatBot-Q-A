package chatdomain.zsxq.model.vo;

public class Group {
    private String group_id;

    private String name;

    private String type;

    public void setGroup_id(String group_id){
        this.group_id = group_id;
    }
    public String getGroup_id(){
        return this.group_id;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getName(){
        return this.name;
    }
    public void setType(String type){
        this.type = type;
    }
    public String getType(){
        return this.type;
    }
}


//zsxq_access_token=93C5AE19-4683-B8B5-E4BB-568E6AA1AE73_1E0AB79EB7853092; abtest_env=product; zsxqsessionid=3cd11cfd781f329b71085977aab0126a; sensorsdata2015jssdkcross=%7B%22distinct_id%22%3A%22185454424218512%22%2C%22first_id%22%3A%2218e55a3a7ca29a-00c5b4d9b9108138-4c657b58-1327104-18e55a3a7cb59e%22%2C%22props%22%3A%7B%22%24latest_traffic_source_type%22%3A%22%E7%9B%B4%E6%8E%A5%E6%B5%81%E9%87%8F%22%2C%22%24latest_search_keyword%22%3A%22%E6%9C%AA%E5%8F%96%E5%88%B0%E5%80%BC_%E7%9B%B4%E6%8E%A5%E6%89%93%E5%BC%80%22%2C%22%24latest_referrer%22%3A%22%22%7D%2C%22identities%22%3A%22eyIkaWRlbnRpdHlfY29va2llX2lkIjoiMThlNTVhM2E3Y2EyOWEtMDBjNWI0ZDliOTEwODEzOC00YzY1N2I1OC0xMzI3MTA0LTE4ZTU1YTNhN2NiNTllIiwiJGlkZW50aXR5X2xvZ2luX2lkIjoiMTg1NDU0NDI0MjE4NTEyIn0%3D%22%2C%22history_login_id%22%3A%7B%22name%22%3A%22%24identity_login_id%22%2C%22value%22%3A%22185454424218512%22%7D%2C%22%24device_id%22%3A%2218e55a3a7ca29a-00c5b4d9b9108138-4c657b58-1327104-18e55a3a7cb59e%22%7D