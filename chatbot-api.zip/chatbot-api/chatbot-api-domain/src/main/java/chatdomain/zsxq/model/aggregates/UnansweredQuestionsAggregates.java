package chatdomain.zsxq.model.aggregates;

import chatdomain.zsxq.model.res.RespData;


/**
 * 未回答问题的聚合信息
 */
public class UnansweredQuestionsAggregates {
    private boolean succeed;
    private RespData resp_data;

    public boolean isSucceed() {
        return succeed;
    }

    public void setSucceed(boolean succeed) {
        this.succeed = succeed;
    }

    public RespData getResp_data() {
        return resp_data;
    }

    public void setResp_data(RespData resp_data) {
        this.resp_data = resp_data;
    }
}
