package chatdomain.zsxq.model.res;

/**
 * 请求问答结果信息
 */
public class AnswerRes {

    private boolean succeed;

    public boolean isSucceed() {
        return succeed;
    }

    public void setSucceed(boolean succeed) {
        this.succeed = succeed;
    }
}
