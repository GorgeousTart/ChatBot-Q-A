package chatdomain.zsxq;

import chatdomain.zsxq.model.aggregates.UnansweredQuestionsAggregates;

import java.io.IOException;

/**
 * 知识星球API接口
 */
public interface IZsxqApi {

    UnansweredQuestionsAggregates queryUnansweredQuestionsTopicId(String groupId, String cookie) throws IOException;

    boolean answer(String groupId,String cookie,String topicId,String text,boolean silenced) throws IOException ;



}
