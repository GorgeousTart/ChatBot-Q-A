package chatdomain.zsxq.model.res;

import chatdomain.zsxq.model.vo.Topics;

import java.util.List;

public class RespData {
    private List<Topics> topics ;

    public List<Topics> getTopics(){
        return topics ;
    }

    private void setTopics(){
        this.topics = topics ;
    }
}
