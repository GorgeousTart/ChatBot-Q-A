package chatbotApiApplication;

import org.apache.http.HttpStatus;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.http.HttpClient;

/**
 * 单元测试
 */

public class ApiTest {

    @Test
    public void query_unanswered_question() throws IOException {
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();
        //获取等我回答页面的问题
        HttpGet get = new HttpGet("https://api.zsxq.com/v2/groups/15555582122142/topics?scope=unanswered_questions&count=20");

        get.addHeader("cookie","zsxq_access_token=93C5AE19-4683-B8B5-E4BB-568E6AA1AE73_1E0AB79EB7853092; abtest_env=product; zsxqsessionid=3cd11cfd781f329b71085977aab0126a; sensorsdata2015jssdkcross=%7B%22distinct_id%22%3A%22185454424218512%22%2C%22first_id%22%3A%2218e55a3a7ca29a-00c5b4d9b9108138-4c657b58-1327104-18e55a3a7cb59e%22%2C%22props%22%3A%7B%22%24latest_traffic_source_type%22%3A%22%E7%9B%B4%E6%8E%A5%E6%B5%81%E9%87%8F%22%2C%22%24latest_search_keyword%22%3A%22%E6%9C%AA%E5%8F%96%E5%88%B0%E5%80%BC_%E7%9B%B4%E6%8E%A5%E6%89%93%E5%BC%80%22%2C%22%24latest_referrer%22%3A%22%22%7D%2C%22identities%22%3A%22eyIkaWRlbnRpdHlfY29va2llX2lkIjoiMThlNTVhM2E3Y2EyOWEtMDBjNWI0ZDliOTEwODEzOC00YzY1N2I1OC0xMzI3MTA0LTE4ZTU1YTNhN2NiNTllIiwiJGlkZW50aXR5X2xvZ2luX2lkIjoiMTg1NDU0NDI0MjE4NTEyIn0%3D%22%2C%22history_login_id%22%3A%7B%22name%22%3A%22%24identity_login_id%22%2C%22value%22%3A%22185454424218512%22%7D%2C%22%24device_id%22%3A%2218e55a3a7ca29a-00c5b4d9b9108138-4c657b58-1327104-18e55a3a7cb59e%22%7D");
        get.addHeader("Content-Type","application/json; charset=UTF-8");

        CloseableHttpResponse response = httpClient.execute(get);
        if(response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
            String res = EntityUtils.toString(response.getEntity());
            System.out.println(res);
        } else {
            System.out.println(response.getStatusLine().getStatusCode());
        }

    }

    @Test
    public void answer() throws IOException {

        CloseableHttpClient httpClient = HttpClientBuilder.create().build();

        HttpPost post = new HttpPost("http://api.zsxq.com/v2/topics/623443213254/answer") ;
        post.addHeader("cookie","zsxq_access_token=93C5AE19-4683-B8B5-E4BB-568E6AA1AE73_1E0AB79EB7853092; abtest_env=product; zsxqsessionid=3cd11cfd781f329b71085977aab0126a; sensorsdata2015jssdkcross=%7B%22distinct_id%22%3A%22185454424218512%22%2C%22first_id%22%3A%2218e55a3a7ca29a-00c5b4d9b9108138-4c657b58-1327104-18e55a3a7cb59e%22%2C%22props%22%3A%7B%22%24latest_traffic_source_type%22%3A%22%E7%9B%B4%E6%8E%A5%E6%B5%81%E9%87%8F%22%2C%22%24latest_search_keyword%22%3A%22%E6%9C%AA%E5%8F%96%E5%88%B0%E5%80%BC_%E7%9B%B4%E6%8E%A5%E6%89%93%E5%BC%80%22%2C%22%24latest_referrer%22%3A%22%22%7D%2C%22identities%22%3A%22eyIkaWRlbnRpdHlfY29va2llX2lkIjoiMThlNTVhM2E3Y2EyOWEtMDBjNWI0ZDliOTEwODEzOC00YzY1N2I1OC0xMzI3MTA0LTE4ZTU1YTNhN2NiNTllIiwiJGlkZW50aXR5X2xvZ2luX2lkIjoiMTg1NDU0NDI0MjE4NTEyIn0%3D%22%2C%22history_login_id%22%3A%7B%22name%22%3A%22%24identity_login_id%22%2C%22value%22%3A%22185454424218512%22%7D%2C%22%24device_id%22%3A%2218e55a3a7ca29a-00c5b4d9b9108138-4c657b58-1327104-18e55a3a7cb59e%22%7D");
        post.addHeader("Content-Type","application/json; charset=UTF-8");
        //后期从OpenAI那里得到的回答装进这里面
        String paramJson = "dsab/n/najdskfjkdsa" ;

        StringEntity stringEntity = new StringEntity(paramJson, ContentType.create("text/Json","UTF-8"));
        post.setEntity(stringEntity);

        CloseableHttpResponse response = httpClient.execute(post);
        if(response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
            String res = EntityUtils.toString(response.getEntity());
            System.out.println(res);
        } else {
            System.out.println(response.getStatusLine().getStatusCode());
        }


    }

    @Test
    public void test_chatGPT() throws IOException {
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();

        HttpPost httpPost = new HttpPost("https://api.openai.com/v1/completions") ;
        httpPost.addHeader("Content-Typq","application/json");
        httpPost.addHeader("Authorization","Bearer sk-proj-EvtUJnK1FLKnhuNToCCOT3BlbkFJ2zuXTaYOT6Cnpwo8DXnK");

        String paramJson = "{\n" +
                "    \"input\": \"帮我写一个冒泡排序\",\n" +
                "    \"model\": \"text-embedding-3-small\"\n" +
                "  }" ;

        StringEntity stringEntity = new StringEntity(paramJson,ContentType.create("text/json","UTF-8"));
        httpPost.setEntity(stringEntity);

        CloseableHttpResponse response = httpClient.execute(httpPost) ;
        if(response.getStatusLine().getStatusCode() == HttpStatus.SC_OK){
            String res = EntityUtils.toString(response.getEntity()) ;
            System.out.println(res);
        } else {
            System.out.println(response.getStatusLine().getStatusCode());
        }


    }


}
